/** Automatically generated file. DO NOT MODIFY */
package com.download.fvd.activity;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}