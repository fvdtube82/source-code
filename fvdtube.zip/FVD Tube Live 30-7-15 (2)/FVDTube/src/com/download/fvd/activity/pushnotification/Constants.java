package com.download.fvd.activity.pushnotification;

public class Constants {
	public static final String SENDER_ID = "367855848006";
	public static final String URL_PUSHNOTIFICATION="url";

public static String MAT_ADVERTISMENT_ID = "167858";
	public static String IP_address ="";
    public static String COUNTRY_NAME ="";

    public static String MAT_CONVERSION_KEY = "6275dd48f285a14f054e8e18597b0d14";
    
   /* push_url =   Constant.PUSH_NOTIFICATION_URL+"token="+registrationId+"&device_id="+getDeviceId()+"&state="+""+"&cname="+Constant.IP_address;*/
    public static final String  PUSH_NOTIFICATION_URL = "http://notonlycrm.com/andriod_push/tvshows/tvsregister.php?app=fvdtube_1mobile&type=fvdtube&";
    
    public static String TopApps_URL="http://native.ymtrack.com/search.php?adnum=40&av=1.0.0&sid=636&aid=588&sv=1.0.0&os=1&udid=5c2e1a988e8023f2a290e8b0f2cbdd1f1198fbbc&icc=";
    	
}
